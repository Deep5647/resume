List<Map<String, dynamic>> categoryName = [
  {
    'img': 'briefcase.png',
    'name': 'Contact Info',
    'page': 'contact',
  },
  {
    'img': 'briefcase.png',
    'name': 'Carrier Objective',
    'page': 'Carrier',
  },
  {
    'img': 'user.png',
    'name': 'Personal Detail',
    'page': 'Personal_Detail',
  },
  {
    'img': 'mortarboard.png',
    'name': 'Education',
    'page': 'Eduction',
  },
  {
    'img': 'thinking.png',
    'name': 'Experiences',
    'page': 'Experiences',
  },
  {
    'img': 'declaration.png',
    'name': 'Technical_Skills',
    'page': 'Technical_Skills',
  },

  {
    'img': 'open-book.png',
    'name': 'Interest/Hobbies',
    'page': 'Interest/Hobbies',
  },

  {
    'img': 'project.png',
    'name': 'Projects',
    'page': 'Projects',
  },

  {
    'img': 'achievement.png',
    'name': 'Achievements',
    'page': 'Achievements',
  },

  {
    'img': 'handshake.png',
    'name': 'References',
    'page': 'References',
  },
  {
    'img': 'declaration.png',
    'name': 'Declaration',
    'page': 'Declaration',
  },
];

List<Map<String, dynamic>> technologiesList = [
  {
    'isSelect': false,
    'langName': 'Flutter',
  },
  {
    'isSelect': false,
    'langName': 'Java',
  },
  {
    'isSelect': false,
    'langName': 'Python',
  },
];